/*jshint browser: true */
/*global chrome*/
/*************************************************************************************************
 * Mdf Dt. 2019.06.20
 * ADuthor : Ykkwon 
 * Description 
   - 유효기간 설정
   - 유효기간 만료 시 실행 불가 기능 추가
   - 비밀번호 설정 기능 추가
*************************************************************************************************/
chrome.tabs.getSelected(null, function (tab) {
  "use strict";

var executeKwax = function(){
 // console.log('in Executekwax');
  if (tab.url.indexOf('http') !== 0 && tab.url.indexOf('https')) {
    document.body.innerHTML = '<p>You can check following schemas only: "http://", "https://"</p>';
    document.body.className = 'result';
    return;
  }
   
  var isIncludeFrame = window.localStorage.isIncludeFrame != 'false';

  // var allowLogging = window.localStorage.allowLogging;
  document.body.innerHTML = '<p>Loading....</p>'
  chrome.tabs.sendMessage(
    tab.id, {
      action: 'execute_' + (isIncludeFrame ? 'with_frames' : 'without_frames'),
      // allowLogging: allowLogging === 'true',
      allowLogging: false,
      ignoreCommon: false
    },
    function (res) {
      if (res && res.err && res.message) {
        document.body.innerHTML = res.message;
        document.body.className = 'result';
      } else {
        window.close();
      }
      return;
    }
  );    
}

// 유효기간 설정
var limitDate = "202001"
var cookieExpireDate = 7  // 쿠키만료일
//var cookieExpireDate = 0  // 쿠키만료일


// 비밀번호 생성 로직  
var getPassword=function(){
    var splitDate = limitDate.split('');
    var validNum = 0
    for (var i of splitDate) {
      validNum += parseInt(Math.pow(i+2, 3));
    }
    validNum = validNum.toString().substr(0, 4);
   //validNum = validNum.toString().substr(validNum.toString().length-4, 4);
    return validNum;
 }

 //현재 날짜 구하기  
  var objdate = new Date();
  var currMonth = objdate.getMonth() + 1

  if (currMonth < 10) {
    currMonth = "0" + currMonth
  }
  var currDate = objdate.getFullYear()+currMonth.toString()
  
  // set Cookies
  var setCookie = function (name, value, exp) {
    var date = new Date();
    if (cookieExpireDate>0){
      date.setTime(date.getTime() + exp * 24 * 60 * 60 * 1000);
    } else {
      date.setTime(date.getTime() + 60 * 1000); // 쿠키 60초로 설정
    }
    document.cookie = name + '=' + value + ';expires=' + date.toUTCString() + ';path=/';
  };

  // get Cookies
  var getCookie = function (name) {
    var value = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
    // value[0] = CKKwaxExpDate=201907

    // '(^|;) ?'  
    // name + '=([^;]*) :  CKKwaxExpDate=;가 아닌 문자가 한개가와도되고 여러개가 와도 된다.
    // ; 가 오거나 마지막이어야 한다. (;|$)

    return value ? value[2] : null;
  };
  
  
  // var inputNum = window.prompt("인증번호를 입력해주세요.","");
  document.getElementById('promptButton').onclick = function () {
    var inputNum = document.getElementById('promptAnswer').value;
    if (inputNum!= getPassword()) {
      window.alert('인증에 실패하였습니다.');
      window.close();
      return;
    }
    //인증에 성공했다면 cookie 설정
   setCookie('CKKwaxExpDate', limitDate, cookieExpireDate); /* ckKwax=OK, 7일 뒤 만료됨 */
   executeKwax();
}

  // var inputNum = window.prompt("인증번호를 입력해주세요.","");
  document.getElementById('promptAnswer').onkeydown = function (e) {
    if(e.keyCode==13){
      document.getElementById('promptButton').click();
    }
  
  }    
  executeKwax()


});