/*jslint browser: true */
/*global chrome */
//수정내용 KWAX 부가기능 추가를 위한 부분 변경(KT 공통영역 제외, 스크롤, 폰트추가)
(function (g, document) {
  "use strict";

  g.achecker = g.achecker || {};
  g.achecker.showOverlay = function () {
    if (document.getElementById("_acheckeroverlay")) {
      document.getElementById("_acheckeroverlay").style.display = "block";
      return;
    }

    var $overlay = document.createElement('div');
    $overlay.id = '_acheckeroverlay';
    $overlay.style.display = 'block';
    $overlay.style.zIndex = '99999999';
    $overlay.style.position = 'fixed';
    $overlay.style.top = '0';
    $overlay.style.right = '0';
    $overlay.style.bottom = '0';
    $overlay.style.left = '400px';
    $overlay.style.backgroundColor = '#fff';
    $overlay.style.opacity = '0.01';
    document.body.appendChild($overlay);
  };
  g.achecker.hideOverlay = function () {
    if (document.getElementById("_acheckeroverlay")) {
      document.getElementById("_acheckeroverlay").style.display = "none";
    }
  };

  var runAchecker = function (isIncludeFrame, allowLogging, ignoreCommon) {
    var frameDocs = [],
      discardFrameUrls = [],
      i, l;
//window.alert("isIncludeFrame=" + isIncludeFrame );
//console.log("isIncludeFrame=" + isIncludeFrame );
//console.log(document.getElementsByTagName("iframe").length)

    if (isIncludeFrame) {
      for (i = 0, l = document.getElementsByTagName("iframe").length; i < l; i++) {
        var f = document.getElementsByTagName("iframe")[i];
        if (f.src === location.href || (f.src.indexOf('http://') === -1 && f.src.indexOf('https://') === -1)) {} else {
          try {
            if (f.src && f.contentDocument) {
              frameDocs.push({
                src: f.src,
                doc: f.contentDocument
              });
            } else if (f.src) {
              discardFrameUrls.push(f.src);
            }
          } catch (e) {
            discardFrameUrls.push(f.src);
          }
        }
      }
    }

    var cwin = g;
    var rdoc = document;
//window.alert("ignoreCommon=" + ignoreCommon) ;
    //공통영역 제외하기
    if(ignoreCommon){
      let commonArray = [];
      commonArray.push(rdoc.getElementById('cfmClHeader'));

      commonArray.push(rdoc.getElementById('cfmClFooter'));
      commonArray.push(rdoc.getElementById('cfmBzHeader'));
      commonArray.push(rdoc.getElementById('cfmBzFooter'));
      commonArray.push(rdoc.getElementById('KTShopHeader'));
      commonArray.push(rdoc.getElementById('footer'));
      commonArray.push(rdoc.getElementById('ollehShopFooter'));
      
    //m.kt.com 공통영역 제외하기      
    commonArray.push(rdoc.getElementsByClassName('main_header_wrap')[0]);
    commonArray.push(rdoc.getElementById('PageLocation'));
    commonArray.push(rdoc.getElementById('mShopSnb'));
                     
    commonArray.push(rdoc.getElementsByClassName('hotdeal_floating_box')[0]);
    commonArray.push(rdoc.getElementsByTagName('footer')[0]);
 
      
      for(let element of commonArray){
        if(element !== null && element !== undefined && typeof(element) === "object"){
             element.remove();
        }
      }

      
    }

    if (!frameDocs.length && !cwin.document.documentElement) {
      return {
        err: true,
        message: 'You cannot check this page.'
      };
    }
    if (cwin.document.getElementsByTagName("frameset").length > 0) {
      var frames = cwin.document.getElementsByTagName("frame"),
        frameUrls = [],
        msg = '<ul>';

      for (i = 0, l = frames.length; i < l; i++) {
        if (frames[i].src.indexOf('http') > -1) {
          msg += '<li><a href="' + frames[i].src + '" target="_blank"">' + frames[i].src + '</a></li>';
        }
      }
      msg += '</ul>';

      return {
        err: true,
        message: '<p>' + g.achecker.i18n.get("CannotCheckFrameset") + '</p>' + msg
      };
    }

    var resultEl = rdoc.createElement("div");
    var resultElInnerSection = rdoc.createElement("section");
    var resultElInnerArticle = rdoc.createElement("article");
    
    //기능 버튼 모음을 하나의 layer로 묶기 위해 추가함. 2019.08.12
    var functionDiv = rdoc.createElement("div")
    functionDiv.className = "kwaxFunction"

    var clear = rdoc.createElement("div");
    clear.className = 'clear';
    
    var res = g.achecker.Wax.run(cwin, rdoc, isIncludeFrame, frameDocs, discardFrameUrls);
    resultEl.id = "kwax-result";
    rdoc.documentElement.className += " kwax-included";
    //add scroll div
    var resultElScroll = rdoc.createElement("div");
    resultElScroll.id = "resultScroll";
    resultElScroll.className = "kwax-result resultScroll";

//    var header = res.header;
    
  //  var filterBar = res.filterBar;
    //var foldBar = res.foldBar;
//    var speakBtn = res.speakBtn; // 2019.09.25 추가
    
    var buttonBar = res.buttonBar;
    var sections = res.sections;
//    var score = g.achecker.Wax.scoreAsElement(cwin, rdoc, sections, allowLogging);
//    var ignoreCommon = KWAX.button.ignoreCommonAreaBtn(ignoreCommon);

    //어느위치에서나 capture할 수 있게 고정된 capture 버튼 기능 추가 2019.08.14
    //  var hiddenCapturediv= rdoc.createElement('div');
    //  hiddenCapturediv.className="hiddenCapture"
    // let $captureBtn2 = KWAX.button.captureBtn(rdoc);
    // $captureBtn2.setAttribute('src', "" + chrome.extension.getURL('/images/capture3.png') + "");   // 투명 이미지로 변경할 것
    
    //hiddenCapturediv.appendChild($captureBtn2)

//    resultEl.appendChild(hiddenCapturediv);
  //  resultEl.appendChild(score);
    //resultElInnerSection.appendChild(header);

    //기능 버튼 모음을 하나의 layer로 묶기 위해 수정. 2019.08.12
//    functionDiv.appendChild(filterBar);
//    functionDiv.appendChild(foldBar);
//    functionDiv.appendChild(speakBtn);//2019.09.25 추가
   functionDiv.appendChild(buttonBar); 
    //functionDiv.appendChild(clear);
//    functionDiv.appendChild(ignoreCommon);
    resultEl.appendChild(functionDiv); //  2019.08.12 작업중 section에 붙혀봄

//    resultElInnerArticle.appendChild(functionDiv);
/*
    resultElInnerArticle.appendChild(filterBar);
    resultElInnerArticle.appendChild(foldBar);
    
    resultElInnerArticle.appendChild(buttonBar);
    resultElInnerArticle.appendChild(clear);
    resultElInnerArticle.appendChild(ignoreCommon);
*/
    var sectionDiv = rdoc.createElement("div");
    sectionDiv.className = 'list-tb';
    
    resultElInnerArticle.appendChild(sectionDiv);
    resultElInnerSection.appendChild(resultElInnerArticle);


    //font load

    var linkFont = document.createElement('link');
    linkFont.href = 'https://fonts.googleapis.com/earlyaccess/notosanskr.css';
    linkFont.rel = 'stylesheet';

    document.querySelector('head').appendChild(linkFont);

    resultEl.appendChild(resultElInnerSection);

    rdoc.body.appendChild(resultElScroll);
    rdoc.body.appendChild(resultEl);
    //resize add-on
    g.isResizing = false;
    KWAX.func.resizeEventInit();
    KWAX.func.addResizeEvent();

    //* target page & K-WAX 충돌 처리
    // 2019.07.23 shop bx-slider 예외처리하기
      KWAX.func.bxsliderFiX()

    window.scroll(0,0);

    //02-11 force wheel event
    document.querySelector('html').addEventListener("wheel", function(){});
    document.querySelector('body').addEventListener("wheel", function(){});


    
    return {
      err: false
    };
  };  //end of runAchecker

  var execute = function (isIncludeFrame, allowLogging, ignoreCommon) {
    if (document.getElementById("kwax-result")) {
      document.body.removeChild(document.getElementById("kwax-result"));
      document.body.removeChild(document.getElementById("resultScroll"));
      document.documentElement.className = document.documentElement.className.replace(/ kwax\-included/, '');
      document.documentElement.style = null;
      return {
        err: false
      };
    }
    var res = runAchecker(isIncludeFrame, allowLogging, ignoreCommon);

    return res;
  };

  


  chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {

    var res;

    if (document.readyState !== 'complete' && !document.getElementById('kwax-result')) {
      //      let message = '<p>Document not Ready, Please try to execute K-WAX after few second</p>';
      let message = '<p>The document is still loading, Please try to execute K-WAX after a few second</p>';
      let err = 'Page Not Ready';

      res = {
        message: message,
        err: err
      };
      sendResponse(res);
      return;
    }
    
    if (request.action === 'execute_with_frames') {
      res = execute(true, request.allowLogging, request.ignoreCommon);
    } else if (request.action === 'execute_without_frames') {
      res = execute(false, request.allowLogging, request.ignoreCommon);
    } else {
      res = {
        err: true,
        message: '<p>Undefined Method</p>'
      };
    }
    sendResponse(res);
  });
}(this, this.document));